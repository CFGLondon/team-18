module.exports = {

    'facebookAuth' : {
        'clientID'      : '1498622890439553', // your App ID
        'clientSecret'  : '9311c73a8f90d3d7c4da88ad9b4f4023', // your App Secret
        'callbackURL'   : 'http://localhost:3000/auth/facebook/callback'
    },

    'twitterAuth' : {
        'consumerKey'       : 'your-consumer-key-here',
        'consumerSecret'    : 'your-client-secret-here',
        'callbackURL'       : 'http://localhost:8080/auth/twitter/callback'
    },
};
